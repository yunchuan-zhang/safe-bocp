from __future__ import print_function, division, absolute_import

import GPy
import scipy
import numpy as np
import pandas as pd

import torch
import os, sys

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
sys.path.append(BASE_DIR)

from safeopt.gp_opt import SafeOpt_Multibeta
from safeopt.utilities import *


def main():

    """ CP stepsize """
    # eta = 0.1

    """ Confidence intervals """
    alpha_target = 0.1

    """ SafeOpt probabilistic guarantee """
    delta = 0.1

    """ Confidence Interval Transform """
    opt_beta_algo = - scipy.stats.norm.ppf(alpha_target/2, loc=0, scale=1)    # safeopt

    # cp_alpha_algo = alpha_target  # naive CP
    # cp_alpha_t = 0.1   # alpha_0
    # cp_beta_t = - scipy.stats.norm.ppf(cp_alpha_t, loc=0, scale=1)
    #
    # active_alpha_algo = (T / (T - 1)) * (alpha_target * (1 - 1 / (T * eta)) - 1 / T)
    # active_beta_algo = - scipy.stats.norm.ppf(active_alpha_algo/2, loc=0, scale=1)  # adaptive CP
    # active_alpha_t = 0.1   # alpha_0
    # active_beta_t = - scipy.stats.norm.ppf(active_alpha_t/2, loc=0, scale=1)
    #
    # min_possible_alpha = 1e-7

    """ Save average results """
    list_vio_opt = torch.zeros(rel)
    # list_vio_cp = torch.zeros(rel)
    # list_vio_active = torch.zeros(rel)

    list_perf_opt = torch.zeros(rel)
    # list_perf_cp = torch.zeros(rel)
    # list_perf_active = torch.zeros(rel)

    """ Define RKHS function generator """
    def rkhs_functions(kernel, rkhs_params, noise_std):

        """

        Parameters
        ----------
        kernel: instance of GPy.kern.*
        rkhs_params: 2D ndarray in the form of [a_i, x_i]
        noise_std: observation noise standard deviation
        bounds: input space

        Returns
        -------
        function: object
            function(x, noise=True)
            A function that takes as inputs new locations x to be evaluated and
            returns the corresponding noisy/noise-free function values. If noise=False is
            set the true function values are returned (useful for plotting).

        """

        def evaluation(x, noise=False):

            """

            Parameters
            ----------
            x: ndarray, input to be evaluated
            noise: True or False, whether noisy or noise-free observations

            Returns
            -------
            y: float, observations

            """

            A = rkhs_params[:, 0].reshape((1, rkhs_params.shape[0]))
            K_arr = np.zeros(rkhs_params.shape[0])

            for i in range(rkhs_params.shape[0]):

                K_arr[i] = kernel.K(x.reshape((1, 1)), np.array([[rkhs_params[i, 1]]]))

            K_arr = np.reshape(K_arr, (rkhs_params.shape[0], 1))

            y = np.dot(A, K_arr)

            if noise:

                y += np.random.normal(loc=0.0, scale=noise_std, size=x.shape[0])

            return y

        return evaluation


    """ Generate functions """
    rkhs_params = np.array([[0.5, 1.1], [0.5, -1.1], [-0.3, 3.3], [-0.3, -3.3], [0.3, 5.5], [0.3, -5.5], [-0.1, -7.4],
                            [-0.1, 7.4], [-0.05, 9.6], [-0.05, -9.6]])
    qfun = rkhs_functions(kernel=kernel, rkhs_params=rkhs_params, noise_std=np.sqrt(noise_var2))

    """ Calculate the RKHS norm bound """

    k_mat = kernel.K(rkhs_params[:, 1].reshape((rkhs_params.shape[0], 1)), rkhs_params[:, 1].reshape((rkhs_params.shape[0], 1)))
    A_mat = np.dot(rkhs_params[:, 0].reshape((rkhs_params.shape[0], 1)), rkhs_params[:, 0].reshape((1, rkhs_params.shape[0])))
    B_max = np.sum(np.multiply(A_mat, k_mat))


    """ Maximum mutual information """

    x_sample = np.linspace(-10.0, 10.0, 1000).reshape((1000, 1))
    noise_K_mat = np.linalg.inv(kernel.K(x_sample, x_sample) + noise_var2 * np.identity(1000))


    def variance_estimate(x_new, kernel):

        """

        Parameters
        ----------
        x_new: ndarray
        kernel: predefined kernel

        Returns
        -------
        sigma: float

        """
        k_self = kernel.K(x_new.reshape(1, 1), x_new.reshape(1, 1))
        k_vector = kernel.K(x_new.reshape(1, 1), x_sample)
        sigma = k_self - np.dot(np.dot(k_vector, noise_K_mat), k_vector.T)

        return float(sigma)


    ed_var = np.zeros(1000)
    for i in range(1000):
        ed_var[i] = variance_estimate(x_new=x_sample[i], kernel=kernel)
    index = np.argsort(ed_var)
    index = index[::-1]
    ed_x = np.zeros((T, 1))
    for j in range(T):
        ed_x[j, 0] = x_sample[index[j], 0]


    def max_mi(x_set, kernel, noise, num):

        """

        Parameters
        ----------
        x_set: 2D ndarray
        noise: observation noise standard deviation

        Returns
        -------
        gamma: mutual information

        """
        k_t = kernel.K(x_set, x_set)
        gamma = 0.5 * np.log2(np.linalg.det(np.identity(num) + k_t * noise ** (-2)))

        return gamma


    def update_safe_dataset(cur_set, x_safe, f_safe_ucb):

        """

        Parameters
        ----------
        cur_set: 2D ndarray
        x_safe: float
        f_safe_ucb: float

        Returns
        -------
        new_set: 2D ndarray

        """
        new_element = np.array([[x_safe, f_safe_ucb]])
        cur_set = np.append(cur_set, new_element, axis=0)
        df = pd.DataFrame(cur_set, columns=['Decision', 'f_UCB'])
        new_df = df.drop_duplicates(subset=['Decision'], keep='last')
        new_set = new_df.to_numpy()

        return new_set

    x0 = np.zeros((1, len(bounds)))
    # x0 = np.ones((1, len(bounds))) * (-7.5)
    vio_trial_opt = 0
    # vio_trial_cp = 0
    # vio_trial_active = 0

    """ SafeOpt verification """
    for r in range(rel):

        q0 = qfun(x0, True)

        """ Define the objective function """
        # fun = sample_safe_fun()
        fun = fun_list[r]

        """ The statistical model of our objective function and safety constraint in well-specified and misspecified cases """
        f0 = fun(x0, True)
        q_mat = q0
        x_mat = x0
        k_opt_mat = kernel.K(x_mat, x_mat)
        # gp = GPy.models.GPRegression(x0, f0, kernel_f, noise_var=noise_var)
        # gp2 = GPy.models.GPRegression(x0, q0, kernel, noise_var=noise_var2)
        gp = GPy.models.GPRegression(x0, f0, kernel_fmis, noise_var=noise_var)
        gp2 = GPy.models.GPRegression(x0, q0, kernel_qmis, noise_var=noise_var2)

        """ The optimization routine """
        opt = SafeOpt_Multibeta([gp, gp2], parameter_set, [-np.inf, 0.], lipschitz=None, beta=2.0,
                                beta_constr=opt_beta_algo, threshold=0.1)
        # cp_opt = SafeOpt_Multibeta([gp, gp2], parameter_set, [-np.inf, 0.], lipschitz=None, beta=2.0, beta_constr=cp_beta_t,
        #                            threshold=0.1)
        # active_cp_opt = SafeOpt_Multibeta([gp, gp2], parameter_set, [-np.inf, 0.], lipschitz=None, beta=2.0,
        #                                   beta_constr=active_beta_t, threshold=0.1)

        # ##########SafeOpt############
        f_opt = []
        f_opt_lcb = []
        x_safe_opt = []
        opt_list = []
        vio_num_opt = 0
        # actual_B = B_max
        # actual_B = 2.0
        # actual_B = 0.56

        # ##########AS-BOCP############
        # f_cp = []
        # f_cp_lcb = []
        # x_safe_cp = []
        # cp_list = []
        # vio_num_cp = 0

        # ########## Safe-BOCP ##########
        # f_active = []
        # f_active_lcb = []
        # x_safe_active = []
        # active_list = []
        # vio_num_active = 0

        # cp_definite_safe_data, active_definite_safe_data = np.zeros([1, 2]), np.zeros([1, 2])
        # cp_definite_safe_data[0, 1] = f0[0, 0]
        # active_definite_safe_data[0, 1] = f0[0, 0]

        for ii in range(T):

            """ noise free constraint """
            # if np.linalg.cond(k_opt_mat) < 1 / sys.float_info.epsilon:
            #     beta_constr_t = float(actual_B - np.dot(np.dot(q_mat.T, np.linalg.inv(k_opt_mat + 0.0 * np.identity(ii+1))), q_mat))
            # else:
            #     beta_constr_t = 0.000000001
            # if beta_constr_t < 0:
            #     beta_constr_t = 0.000000001
            beta_constr_t = actual_B

            """ noisy constraint """
            # gamma_t = max_mi(x_set=ed_x[0:ii].reshape(ii, 1), kernel=kernel, noise=noise_var2, num=ii)
            # update beta_t based on mutual information and RKHS norm
            # beta_constr_t = actual_B + 4 * np.sqrt(noise_var2) * np.sqrt(gamma_t + 1 + np.log(1 / delta))

            opt.beta_constr = beta_constr_t
            # opt.beta = beta_constr_t
            # opt.beta_constr = 2.0
            opt.beta = 2.0

            # if ii > 0:
            #
            #     if active_alpha_t_used_for_beta == min_possible_alpha and cp_alpha_t_used_for_beta == min_possible_alpha:
            #
            #         active_max_index = np.argmax(active_definite_safe_data[:, 1])
            #         x_next_active = active_definite_safe_data[active_max_index, 0].reshape(1,)
            #         x_next_opt = opt.optimize()
            #         cp_max_index = np.argmax(cp_definite_safe_data[:, 1])
            #         x_next_cp = cp_definite_safe_data[cp_max_index, 0].reshape(1,)
            #
            #     elif active_alpha_t_used_for_beta == min_possible_alpha and cp_alpha_t_used_for_beta != min_possible_alpha:
            #
            #         active_max_index = np.argmax(active_definite_safe_data[:, 1])
            #         x_next_active = active_definite_safe_data[active_max_index, 0].reshape(1,)
            #         x_next_opt = opt.optimize()
            #         x_next_cp = cp_opt.optimize()
            #
            #     elif active_alpha_t_used_for_beta != min_possible_alpha and cp_alpha_t_used_for_beta == min_possible_alpha:
            #
            #         x_next_active = active_cp_opt.optimize()
            #         x_next_opt = opt.optimize()
            #         cp_max_index = np.argmax(cp_definite_safe_data[:, 1])
            #         x_next_cp = cp_definite_safe_data[cp_max_index, 0].reshape(1,)
            #
            #     else:
            #         # Obtain next query point
            #         x_next_opt = opt.optimize()
            #         x_next_cp = cp_opt.optimize()
            #         x_next_active = active_cp_opt.optimize()
            # else:
            #     # Obtain next query point
            #     x_next_opt = opt.optimize()
            #     x_next_cp = cp_opt.optimize()
            #     x_next_active = active_cp_opt.optimize()

            x_next_opt = opt.optimize()

            """ Get a measurement from the real system """
            f_next_opt = fun(x_next_opt, True)
            q_next_opt = qfun(x_next_opt, True)

            y_next_opt = np.concatenate((f_next_opt, q_next_opt), axis=1)

            # f_next_cp = fun(x_next_cp, True)
            # q_next_cp = qfun(x_next_cp, True)
            # y_next_cp = np.concatenate((f_next_cp, q_next_cp), axis=1)
            # y_ucb_cp = cp_opt.get_ucb_estimate(xnew=x_next_cp, low_tail=2.5, up_tail=97.5)

            # f_next_active = fun(x_next_active, True)
            # q_next_active = qfun(x_next_active, True)
            # y_next_active = np.concatenate((f_next_active, q_next_active), axis=1)
            # y_ucb_active = active_cp_opt.get_ucb_estimate(xnew=x_next_active, low_tail=2.5, up_tail=97.5)

            """ Add this to the GP model """
            evals_opt = {'iter': ii+1, 'x': float(x_next_opt), 'f': float(f_next_opt), 'q': float(q_next_opt)}
            opt_list.append(evals_opt)
            # evals_cp = {'iter': ii+1, 'x': float(x_next_cp), 'f': float(f_next_cp), 'q': float(q_next_cp),
            #             'f_ucb': y_ucb_cp}
            # cp_list.append(evals_cp)

            # evals_active = {'iter': ii+1, 'x': float(x_next_active), 'f': float(f_next_active), 'q': float(q_next_active),
            #                 'f_ucb': y_ucb_active}
            # active_list.append(evals_active)  # save results


            opt.add_new_data_point(x_next_opt, y_next_opt)
            # cp_opt.add_new_data_point(x_next_cp, y_next_cp)
            # active_cp_opt.add_new_data_point(x_next_active, y_next_active)

            """ Safety impacts """
            if evals_opt['q'] >= 0:  # safe
                # f_opt.append(evals_opt['f'])
                x_safe_opt.append(evals_opt['x'])
            else:
                vio_num_opt = vio_num_opt + 1

            # update matrices for noise free case
            # x_mat = np.concatenate((x_mat, x_next_opt.reshape(1, 1)), axis=0)
            # q_mat = np.concatenate((q_mat, q_next_opt), axis=0)
            # k_opt_mat = kernel.K(x_mat, x_mat)

            # if evals_cp['q'] >= 0:  # safe
            #     err_t = 0
            #     # f_cp.append(evals_cp['f'])
            #     x_safe_cp.append(evals_cp['x'])
            #     cp_definite_safe_data = update_safe_dataset(cp_definite_safe_data, evals_cp['x'], evals_cp['f_ucb'])
            # else:
            #     err_t = 1
            #     vio_num_cp = vio_num_cp + 1
            # cp_alpha_t = cp_alpha_t - eta * (err_t - cp_alpha_algo)
            # if cp_alpha_t > 1.0:
            #     cp_alpha_t_used_for_beta = 1.0
            # elif cp_alpha_t <= 0.0:
            #     cp_alpha_t_used_for_beta = min_possible_alpha
            # else:
            #     cp_alpha_t_used_for_beta = cp_alpha_t

            # cp_beta_t = - scipy.stats.norm.ppf(cp_alpha_t_used_for_beta / 2, loc=0, scale=1)

            # cp_opt.beta = cp_beta_t
            # cp_opt.beta_constr = cp_beta_t
            #
            # if evals_active['q'] >= 0:  # safe
            #     err_t = 0
                # f_active.append(evals_active['f'])
            #     x_safe_active.append(evals_active['x'])
            #     active_definite_safe_data = update_safe_dataset(active_definite_safe_data, evals_active['x'], evals_active['f_ucb'])
            # else:
            #     err_t = 1
            #     vio_num_active = vio_num_active + 1
            # active_alpha_t = active_alpha_t - eta * (err_t - active_alpha_algo)
            # if active_alpha_t > 1.0:
            #     active_alpha_t_used_for_beta = 1.0
            # elif active_alpha_t <= 0.0:
            #     active_alpha_t_used_for_beta = min_possible_alpha
            # else:
            #     active_alpha_t_used_for_beta = active_alpha_t

            # active_beta_t = - scipy.stats.norm.ppf(active_alpha_t_used_for_beta / 2, loc=0, scale=1)
            # active_cp_opt.beta = active_beta_t
            # active_cp_opt.beta_constr = active_beta_t

        vio_opt = vio_num_opt / T
        # vio_cp = vio_num_cp / T
        # vio_active = vio_num_active / T

        if vio_num_opt > 0:
            vio_trial_opt = vio_trial_opt + 1

        # if vio_num_cp > 0:
        #     vio_trial_cp = vio_trial_cp + 1
        #
        # if vio_num_active > 0:
        #     vio_trial_active = vio_trial_active + 1

        """ Performance ratio """
        f_ground = fun(x_sample, noise=False)
        q_ground = np.zeros(len(x_sample))
        for s in range(len(x_sample)):
            q_ground[s] = qfun(x_sample[s], noise=False)
        q_ground = q_ground.reshape(len(x_sample), 1)
        y_label = (q_ground[:, 0] >= 0) + 0
        f_safe_ground = y_label * f_ground[:, 0]
        f_max = f_safe_ground.max()
        f_min = f_safe_ground.min()
        f_gap = f_max - f_min

        for js in range(len(x_safe_opt)):
            f_opt_lcb.append(opt.get_lcb_estimate(xnew=np.array([x_safe_opt[js]]), low_tail=2.5, up_tail=97.5))
        opt_index = np.argmax(f_opt_lcb)
        x_opt_final = x_safe_opt[opt_index]
        # perf_opt = (f_opt[-1] - f_min) / f_gap
        perf_opt = (fun(x_opt_final, noise=False)[0, 0] - f_min) / f_gap

        if perf_opt > 1:
            perf_opt = 1.0

        # for js in range(len(x_safe_cp)):
        #     f_cp_lcb.append(cp_opt.get_lcb_estimate(xnew=np.array([x_safe_cp[js]]), low_tail=2.5, up_tail=97.5))
        # cp_index = np.argmax(f_cp_lcb)
        # x_cp_final = x_safe_cp[cp_index]
        # perf_cp = (fun(x_cp_final, noise=False)[0, 0] - f_min) / f_gap
        # perf_cp = (f_cp[-1] - f_min) / f_gap

        # if perf_cp > 1:
        #     perf_cp = 1.0

        # for js in range(len(x_safe_active)):
        #     f_active_lcb.append(active_cp_opt.get_lcb_estimate(xnew=np.array([x_safe_active[js]]),
        #                                                        low_tail=2.5, up_tail=97.5))
        # active_index = np.argmax(f_active_lcb)
        # x_active_final = x_safe_active[active_index]

        # perf_active = (fun(x_active_final, noise=False)[0, 0] - f_min) / f_gap

        # perf_active = (f_active[-1] - f_min) / f_gap

        # if perf_active > 1:
        #     perf_active = 1.0

        list_vio_opt[r] = vio_opt
        list_perf_opt[r] = perf_opt

        # list_vio_cp[r] = vio_cp
        # list_perf_cp[r] = perf_cp
        #
        # list_vio_active[r] = vio_active
        # list_perf_active[r] = perf_active

    """ Violation prob among all iterations """
    avg_vio_opt = torch.mean(list_vio_opt)
    std_vio_opt = torch.std(list_vio_opt, unbiased=True)

    # avg_vio_cp = torch.mean(list_vio_cp)
    # std_vio_cp = torch.std(list_vio_cp, unbiased=True)
    #
    # avg_vio_active = torch.mean(list_vio_active)
    # std_vio_active = torch.std(list_vio_active, unbiased=True)

    """ Performance ratio"""
    avg_perf_opt = torch.mean(list_perf_opt)
    std_perf_opt = torch.std(list_perf_opt, unbiased=True)

    # avg_perf_cp = torch.mean(list_perf_cp)
    # std_perf_cp = torch.std(list_perf_cp, unbiased=True)
    #
    # avg_perf_active = torch.mean(list_perf_active)
    # std_perf_active = torch.std(list_perf_active, unbiased=True)

    eval_dict = {'vio prob': avg_vio_opt, 'vio prob std': std_vio_opt, 'vio trials': vio_trial_opt / rel,
                 'perf': avg_perf_opt, 'perf std': std_perf_opt}

    torch.save(eval_dict, './saved_dict_' + 'actual_B_' + str(ratio) + 'kernel_len_' + str(ql))


""" Measurement noise """
noise_var = 0.05 ** 2
# noise_var2 = 1e-1
# noise_var = 0.0
noise_var2 = 0.0

"""Maximum number of iterations"""
T = 25

""" Bounds on the inputs variable """
bounds = [(-10., 10.)]

""" Define RKHS Kernel """
kernel = GPy.kern.RBF(input_dim=len(bounds), variance=2., lengthscale=0.9, ARD=True)
kernel_f = kernel.copy()


""" set of parameters """
parameter_set = linearly_spaced_combinations(bounds, 1000)

""" Save objective functions """
rel = 500
fun_list = []

""" Generate function with safe initial point at x=0 """


def sample_safe_fun():

    fun = sample_gp_function(kernel_f, bounds, noise_var, 1000)

    return fun


for r in range(rel):
    fun_list.append(sample_safe_fun())

B_max = np.sqrt(1.7)
# mis_ratio_set = [0.0, 0.05, 0.1, 0.2, 0.5, 1.0, 2.0, 5.0, 10.0, 20.0, 50.0, 100.0]
mis_ratio_set = [0.00001, 0.0001, 0.001, 0.01, 0.05, 0.1, 0.2, 0.5, 1.0, 5.0, 10.0, 50.0, 80.0, 90.0, 100.0, 130.0]
# B_set = B_max * ratio_set
for ratio in mis_ratio_set:

    """ Define misspecified kernel """
    actual_B = B_max * ratio
    ql = 2.7
    kernel_qmis = GPy.kern.RBF(input_dim=len(bounds), variance=2., lengthscale=2.7, ARD=True)
    kernel_fmis = kernel_qmis.copy()

    print('B algo:', actual_B)
    if __name__ == '__main__':
        main()

well_ratio_set = [0.00001, 0.0001, 0.001, 0.01, 0.05, 0.1, 0.2, 0.5, 1.0, 2.0]
for ratio in well_ratio_set:

    """ Define misspecified kernel """
    actual_B = B_max * ratio
    ql = 0.9
    kernel_qmis = GPy.kern.RBF(input_dim=len(bounds), variance=2., lengthscale=0.9, ARD=True)
    kernel_fmis = kernel_qmis.copy()

    print('B algo:', actual_B)
    if __name__ == '__main__':
        main()

# for actual_B in B_set:
#
#     """ Define misspecified kernel """
#     ql = 0.5
#     kernel_qmis = GPy.kern.RBF(input_dim=len(bounds), variance=2., lengthscale=0.5, ARD=True)
#     kernel_fmis = kernel_qmis.copy()
#
#     print('B algo:', actual_B)
#     if __name__ == '__main__':
#         main()

# ql = 0.9
# ratio = 0.01
# kernel_qmis = GPy.kern.RBF(input_dim=len(bounds), variance=2., lengthscale=0.9, ARD=True)
# kernel_fmis = kernel_qmis.copy()
# actual_B = 0.01 * B_max
# print('B algo:', actual_B)
# if __name__ == '__main__':
#     main()
#
#
# ql = 2.7
# ratio = 0.01
# kernel_qmis = GPy.kern.RBF(input_dim=len(bounds), variance=2., lengthscale=2.7, ARD=True)
# kernel_fmis = kernel_qmis.copy()
# actual_B = 0.01 * B_max
# print('B algo:', actual_B)
# if __name__ == '__main__':
#     main()

